<?php include "templates/header.php"; ?>

<ul>
<li>
  <a href="update.php"><strong>Update Employee</strong></a> - edit a user
</li>
<li>
  <a href="update2.php"><strong>Update Department</strong></a> - edit a user
</li>
<li>
  <a href="update3.php"><strong>Update Project</strong></a> - edit a user
</li>
<li>
  <a href="update4.php"><strong>Update Works</strong></a> - edit a user
</li>
</ul>

<?php include "templates/footer.php"; ?>
