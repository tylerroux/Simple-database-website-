<?php include "templates/header.php"; ?>

<ul>
<li>
  <a href="delete.php"><strong>Delete Employee</strong></a> - delete a user
</li>
<li>
  <a href="delete2.php"><strong>Delete Department</strong></a> - delete a user
</li>
<li>
  <a href="delete3.php"><strong>Delete Project</strong></a> - delete a user
</li>
<li>
  <a href="delete4.php"><strong>Delete Works</strong></a> - delete a user
</li>
<ul>

<?php include "templates/footer.php"; ?>
