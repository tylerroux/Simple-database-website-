<?php include "templates/header.php"; ?>

<ul>
<li>
  <a href="create.php"><strong
    >Insert into Employee</strong></a> - add a user
</li>
<li>
  <a href="create2.php"><strong
    >Insert into Department</strong></a> - add a user
</li>
<li>
  <a href="create3.php"><strong
    >Insert into Project</strong></a> - add a user
</li>
<li>
  <a href="create4.php"><strong
    >Insert into Works</strong></a> - add a user
</li>
<ul>
  <?php include "templates/footer.php"; ?>
