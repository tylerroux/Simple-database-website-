<?php include "templates/header.php"; ?>

<ul>
<li>
  <a href="read.php"><strong>Find Employee</strong></a> - find a user
</li>
<li>
  <a href="read2.php"><strong>Find Department</strong></a> - find a user
</li>
<li>
  <a href="read3.php"><strong>Find Project</strong></a> - find a user
</li>
<li>
  <a href="read4.php"><strong>Find Works</strong></a> - find a user
</li>
</ul>

<?php include "templates/footer.php"; ?>
