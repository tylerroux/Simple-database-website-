<?php include "templates/header.php"; ?>

    <ul>
      <li>
        <a href="createmain.php"><strong
          >Insert</strong></a> - add a user
      </li>
      <li>
        <a href="readmain.php"><strong>Find</strong></a> - find a user
      </li>
      <li>
        <a href="updatemain.php"><strong>Update</strong></a> - edit a user
      </li>
      <li>
        <a href="deletemain.php"><strong>Delete</strong></a> - delete a user
     </li>
    </ul>

<?php include "templates/footer.php"; ?>
